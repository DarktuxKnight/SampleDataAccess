CREATE FUNCTION "overlaps"(timestamp without time zone, interval, timestamp without time zone, timestamp without time zone)
  RETURNS boolean
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;

