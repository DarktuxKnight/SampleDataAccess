CREATE VIEW role_usage_grants AS
  SELECT usage_privileges.grantor, usage_privileges.grantee, usage_privileges.object_catalog, usage_privileges.object_schema, usage_privileges.object_name, usage_privileges.object_type, usage_privileges.privilege_type, usage_privileges.is_grantable FROM information_schema.usage_privileges WHERE (((usage_privileges.grantor)::text IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR ((usage_privileges.grantee)::text IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)));

