CREATE FUNCTION int8pl_inet(bigint, inet)
  RETURNS inet
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

