CREATE FUNCTION interval_pl_date(interval, date)
  RETURNS timestamp without time zone
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

