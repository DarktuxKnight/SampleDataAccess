CREATE FUNCTION totalnonreboots()
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    badservers integer;
BEGIN
   SELECT count(*) into badservers FROM serverschema.serverinfo WHERE lastreboot > 20;
   RETURN badservers;
END;
$$;

