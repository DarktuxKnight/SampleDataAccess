CREATE VIEW server_reboots AS
  SELECT serverinfo.name, serverinfo.lastreboot FROM serverschema.serverinfo;

