CREATE FUNCTION totalrecords()
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
    total integer;
BEGIN
   SELECT count(*) into total FROM serverschema.serverinfo;
   RETURN total;
END;
$$;

